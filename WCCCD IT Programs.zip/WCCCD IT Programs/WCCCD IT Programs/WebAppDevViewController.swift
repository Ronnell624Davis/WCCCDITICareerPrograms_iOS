//
//  WebAppDevViewController.swift
//  WCCCD IT Programs
//
//  Created by Ronnell Davis on 11/14/17.
//  Copyright © 2017 Wayne County Community District College. All rights reserved.
//


import UIKit

class WebAppDevViewController: UIViewController {
    
    
    @IBOutlet weak var WebAppDev: UIWebView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let url = URL(string: "http://www.wcccd.edu/academic/pdfs/CIS_App_Developer.pdf")
        
        WebAppDev.loadRequest(URLRequest(url: url!))
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
