//
//  GeneralInformation.swift
//  WCCCD IT Programs
//
//  Created by Ronnell Davis on 11/6/17.
//  Copyright © 2017 Wayne County Community District College. All rights reserved.
//

import UIKit

class GeneralInformationViewController: UITableViewController {
    
    var contacts = ["Contact Us"]
    
    //MARK: - TableView data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contacts.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "GeneralInfoCell" , for: indexPath)
        
        let contactName = contacts[indexPath.row]
        cell.textLabel?.text = contactName
        cell.detailTextLabel?.text = "cisprograms@wcccd.edu"
        
        
        return cell
    }
    
       
    
}
